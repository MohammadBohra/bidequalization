sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.aramco.formulaadminapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);